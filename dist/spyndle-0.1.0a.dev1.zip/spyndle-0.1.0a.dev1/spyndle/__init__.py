# __init__.py
__version__ = "0.1.0a.dev1"


from propagation.XCST import computeXCST
