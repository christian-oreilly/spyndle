Toolbox for analyzing sleep spindles.

Please consult https://bitbucket.org/christian_oreilly/spyndle/wiki/Home for more information.